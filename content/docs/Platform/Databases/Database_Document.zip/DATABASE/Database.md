[ ![Logo](./Screenshots/Logo.png)](https://utho.com/)
<br>
<br>
# Databases
--- 
Databases in cloud servers refer to the storage and management of data within cloud computing environments. Traditionally, databases were hosted on physical servers maintained by organizations themselves. However, with the advent of cloud computing, databases can now be hosted on virtual servers provided by cloud service providers.

### Databases offer several benefits:
- Scalability
- Cost-effectiveness
- Accessibility
- Reliability and redundancy
- Security

### Steps for approaching the Databases:
---
#### Visit on the link given below:
>
[Console url](https://console.utho.com/)
1. This link will redirect you to the Dashboard after Login of the cloud platform. 
![Dashboard](./Screenshots/Dashboard.png)
<br>

2.  Here we will get 2 options to reach the Databases tab.
- Deploy new (Dropdown)
- L.H.S tab
![DB_Process_1](./Screenshots/DB_process_1.png)
<br>

3.  After clicking it will redirect  you to the database homepage.
![DB_Process_2](./Screenshots/DB_Process_2.png)
<br>

4.  Now for creating a new database cluster click on create  cluster or create database cluster.
![DB_Process_3](./Screenshots/DB_Process_3.png)
<br>

5. It will  redirect you to the requirements and create cluster page.
    Where the user have to choose the data accordings to there requirements such as:
![DB_Process_4](./Screenshots/DB_Process_4.png)
<br>

6. Now from  Select DC location , select one required location.
![DB_Process_5](./Screenshots/DB_Process_5.png)
<br>

7. Now moving forword we have to Select Database Cluster with there version which is required.
![DB_Process_6](./Screenshots/DB_Process_6.png)
<br>

8. In this user have to select which mode of billing cycle he/she prefer from the given options:
- Hourly
- Monthly  
- Yearly

![DB_Process_7](./Screenshots/DB_Process_7.png)
<br>

9. Now from the Select Plan Type , choose the required plan from the given options:
- Basic Plan
- CPU Optimized
- Memory Optimized

![DB_Process_8](./Screenshots/DB_Process_8.png)
<br>

10. If the user needs Set Number of Replica of his cluster , so that it can keep his website up even when his main wesite is facing issue. From here he/she can select maximum upto 3 Replica.
![DB_Process_9](./Screenshots/DB_Process_9.png)
<br>

11. VPC Network allows users to create and manage isolated networks within the cloud infrastructure. VPC networks enable users to deploy resources such as virtual machines (VMs), databases, and other cloud services securely and privately.
![DB_Process_10](./Screenshots/DB_Process_10.png)
<br>

12. In Add security group , user can create and select the firewalls for the server.
![DB_Process_11](./Screenshots/DB_Process_11.png)
<br>

13. User can name his cluster as per his perception in Name Your Cluster tab.
![DB_Process_12](./Screenshots/DB_Process_12.png)
<br>

14. After filling all the details then on clicking on the create cluster button.
![DB_Process_13](./Screenshots/DB_Process_13.png)
<br>

15. A new db cluster will be created and you will be automatically redirected to the homepage of database.
![DB_Process_14](./Screenshots/DB_Process_14.png)
<br>

After the cluster is created , its internal functionalities will be seen after clicking on the Manage Button as shown in the below snippet.
>
---
![DB_Process_15](./Screenshots/DB_Process_15.png)
<br>

After clicking on the manage a new screen will occur.
![DB_Process_16](./Screenshots/DB_Process_16.png)
<br>

##### Which contains various functionalities of Database stated below:

After clicking on manage button from dashboard it will redirect to this page where user will get all the oints mentioned below for in deoth understanding of the product. 
![DB_Process_17](./Screenshots/DB_Process_17.png)

1. **Connection Details**
   In cloud computing, "Connection Details" typically refer to the information required to establish connections between different components or services within a cloud environment.
   These details can include various parameters such as:

    Endpoint Addresses
    Port Numbers
    Protocol
    Authentication Credentials
    Security Settings
    Connection Timeout Settings

2. **Nodes**
    With the help of Nodes we can add additional replica of our cluster. For both read only and edit too.
3. **Databases**
    In databases user can create database and manage the permissions he want to provide to the reated database.
    Also user have the access to delete his created databases.
4. **Users**
    In this section user can create or add the user who can access that database for the work.
    Also ownwer have the access to delete his created user for databases.
5. **Connection Pool**
    A connection pool in the context of cloud computing refers to a mechanism for efficiently managing and reusing database connections within cloud-based applications. It is a critical component for optimizing the performance and scalability of applications that interact with databases hosted in the cloud.
    In this, Connection pooling uses PgBouncer to manage backend processes. Each pool shares its assigned backend processes with up to 5000 client connections
6. **Backups**
    Backups are an essential aspect of maintaining data integrity and availability in cloud server environments. Cloud providers offer various backup solutions and features to help users protect their data from loss or corruption. User can add as many backups he want.
    With the help of backups user can save his cluster from any mishappening.
7. **Firewall**
    Firewalls in the cloud serve the same fundamental purpose as traditional network firewalls: to monitor and control incoming and outgoing network traffic based on predetermined security rules. However, in a cloud environment, firewalls are implemented and managed differently due to the distributed and dynamic nature of cloud computing.
    Here user can also add the firewall he needed.
8. **Trusted Hosts**
    In cloud computing, "trusted hosts" typically refer to entities, such as servers, virtual machines, or services, that are deemed trustworthy within a cloud environment. These trusted hosts are often granted certain privileges or permissions based on their established trustworthiness.
    In this user can add the trusted IP address from where the server can get accessed.
9. **Destroy**
     In destroy the user can destroy/delete his cluster permanently , which cannot be accessed again.
---
##### Managed By: Utho Platforms Pvt. Ltd
##### Created By: Ayush Kumar