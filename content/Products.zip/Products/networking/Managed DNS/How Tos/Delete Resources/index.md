---
weight: 30
title: "Delete Resources"
title_meta: "Delete Resources"
description: "The Manage section of EBS allows you to configure settings, resize volumes, attach or detach them from instances, and destroy volumes when no longer needed."
keywords: ["Elastic Block Storage", "storage"]
tags: ["utho platform","Elastic Block Storage"]
date: "2024-03-07T17:25:05+01:00"
lastmod: "2024-03-07T17:25:05+01:00"
draft: false 
aliases: ["/products/networking/Managed DNS/How Tos/Delete Resources"]
icon: guides
---
## Actions to delete the added resources

---

For each DNS record, an **Action** column will provide options to  **Delete** the record.

Type value can be differ way to delete the resources will be same.
![1743751738271](image/index/1743751738271.png)
