---
weight: 30
title: "Power"
title_meta: "Manage Cloud on the Utho Platform"
description: "Manage your cloud instance using simply clicks on utho platform"
keywords: ["cloud", "instances",  "ec2", "server", "graph"]
tags: ["utho platform","cloud"]
date: "2024-03-07T17:25:05+01:00"
lastmod: "2024-03-07T17:25:05+01:00"
draft: false
toc: true
aliases: ['/products/cloud/manage-cloud/power']
icon: "cpanel"
tab: true
---
Users can manage the power state and access settings of their cloud instance. The available options include:

### Console Access :

![1718897498687](image/index/1718897498687.png)Provides users with a console interface to directly access the cloud instance as if they were physically present at the server. This can be useful for troubleshooting and performing administrative tasks that require direct access.

1) Click on open console button  then it will  redirect user to terminal page.
