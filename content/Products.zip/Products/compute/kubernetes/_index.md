---
title: "Kubernetes"
weight: 3 
menu:
  main:
    name: Kubernetes
    weight: 3 
description: ""
icon: "kubernetes"
date: "2024-03-07T17:25:05+01:00"
lastmod: "2024-03-07T17:25:05+01:00"
draft: false
toc: true
---
