---
weight: 20
title: "VPC"
title_meta: "Manage kubernetes on the Utho Platform"
description: "Manage your kubernetes instance using simply clicks on utho platform"
keywords: ["kubernetes", "instances",  "ec2", "server", "graph"]
tags: ["utho platform","kubernetes"]
date: "2024-03-07T17:25:05+01:00"
lastmod: "2024-03-07T17:25:05+01:00"
draft: false
toc: true
aliases: ['/products/compute/kubernetes/manage-kubernetes/vpc']
icon: "vpc"
tab: true
---
Utho's VPC feature enables users to configure and manage VPC settings for their kubernetes, offering flexibility in network security.

### Vpc configuration

here you can see the VPC details attached with kubernetes.

![1718891929733](image/index/1718891929733.png)
